import shutil
import os

current_directory = os.getcwd()
target_dir_path = current_directory+"/APItoSQSLambdaDir"
parent_target_dir_path = os.path.dirname(target_dir_path)
target_dir_name = os.path.basename(target_dir_path)
print(parent_target_dir_path)
print(target_dir_name)

zip_path = current_directory+"/APItoSNSLambdaDir/lambda_handler"
print(zip_path)


shutil.make_archive(zip_path, 'zip', root_dir=parent_target_dir_path, base_dir=target_dir_name)
